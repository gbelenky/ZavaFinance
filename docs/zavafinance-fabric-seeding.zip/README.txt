ZavaFinance resolver seeding scripts

Read Section 6 of customer-it-installation-guide.pdf before running anything.
These scripts publish resolver metadata and its Search projection. They DO NOT
create the original nine finance tables or provision Azure/Bot resources.
No original financial dataset, credentials or dependency binaries are included.

Preserve scripts\fabric and tools relative paths. Use an approved Windows
PowerShell 7.6/.NET 10 publishing workstation and Azure CLI. Supply the compatible
SQL-client dependency folder via -SqlClientDirectory to Test-ResolverData.ps1 and
Publish-ResolverSearch.ps1 (even when the hosted agent is Python).
PySpark execution is in Fabric. The original finance Delta tables must already
exist at the exact Tables/<table_name> paths documented in the PDF.

Review the scripts and verify each file hash against seeding-manifest.json before
execution. Record the separately approved archive hash. A local hash manifest
detects modification; it is not a trusted publisher signature.
Obtain script approval/signing through customer policy. Do not weaken execution
policy, application control, Conditional Access or resource firewalls.

Run: stage -> wait for SQL sync -> Test-ResolverData -> Publish-ResolverSearch
-> review results -> Publish-ResolverData -ActivateRelease -> SQL readback.
The activation switch does not independently recheck Search. Operator review
of the preceding gates is mandatory. Keep the previous release/index.
Detailed parameters, required permissions, expected output and recovery
instructions are in the accompanying PDF. Do not run scripts with sample IDs.

Offline catalogue tests use Python's standard-library unittest:
python -B -m unittest discover -s .\tools -p test_resolver_catalog.py -v
These tests do not prove cloud deployment, finance baseline accuracy or access
control in the customer's tenant.